class MainController < ApplicationController
  def index
    session[:everybody] = User.all
    render 'index.html.erb'
  end

  def add_user
    render 'new.html.erb'
  end

  def create
    user = User.new(first_name: params[:first],last_name: params[:last],email:params[:email])
    if user.save
      flash[:hi] = "User added to table!"
      redirect_to('/')
    else
      flash[:hi] = "Error: every field must be 2-20 characters and then email must be valid!"
      redirect_to :back
    end
  end

  def show
    @person = User.find(params[:id])
  end

  def edit
    @clown = User.find(params[:id])
  end

  def update
    if User.update(params[:id], :first_name => params[:first], :last_name => params[:last], :email => params[:email])
      flash[:hi] = "Updated the information of with the id #{params[:id]}"
      redirect_to('/')
    else
      flash[:hi] = "Error: every field must be 2-20 characters and then email must be valid!"
      redirect_to :back
    end
  end

  def delete

    User.find(params[:id]).delete
    flash[:hi] = "User #{params[:id]} deleted"
    redirect_to('/')
  end

end
