Rails.application.routes.draw do
  get '/', :controller=>'main', :action=>'index'

  get 'new_user', :controller=>'main', :action=>'add_user'

  post 'create', :controller=>'main', :action=> 'create'

  get 'users/:id', :controller=>'main', :action=> 'show'

  get 'users/:id/edit', :controller=>'main', :action=> 'edit'

  post 'update', :controller=>'main', :action=>'update'

  delete '/destroy/:id', :controller=>'main', :action=> 'delete'

end
